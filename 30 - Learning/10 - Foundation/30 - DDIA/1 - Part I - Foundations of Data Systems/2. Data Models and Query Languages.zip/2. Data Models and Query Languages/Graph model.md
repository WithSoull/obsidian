Для сложных *many-to-many* отношений графовая модель подходит отлично, хотя для не особо сложных подходит нормализованная relational модель. Если связи в основном *one-to-many*(tree-structered data), то документо-ориентированная модель бы хорошо вписалась.

У графа есть:
1) *Vertices* - nodes / entities / вершины
2) *Edges* - relationships / arcs / ребра

Графы не ограниченны однородным типом данных: это мощная возможность данной модели данных, которая позволяет хранить разные типы объектов в одном хранилище.

Напимер Facebook:
1) Verices: люди, локации, события, комментарии пользователей
2) Edges: друзья, кто комментирует какой пост, кто добавил какое событие

![[99 - Meta/02 - Медиа/Pasted image 20251008192025.png]]

Есть разные способы структурировать данные и строить запросы в графах, как минимум потомучто есть разные виды графов:
- [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Property-graph model|Property model]] (реализованная Neo4j, Titan и InfiniteGraph)
- [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Triple-store model]] (реализованная Datomic, AllegroGraph и другие)

Есть разные языки запросов:
- декларативные:
	- [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Cypher|Cypher]] - язык для [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Property-graph model|property-graph model]], а конкретно Neo4j
	- [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/SPARQL|SPARQL]] - язык запросов для [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Triple-store model|triple-store model]] которые используют [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Semantic web & RDF#^840081|RDF]]. 
	- [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Datalog]] - язык запросов для Datomic
	- [[30 - Learning/10 - Foundation/30 - DDIA/1. Part I - Foundations of Data Systems/2. Data Models and Query Languages/Grahp queries in SQL|SQL]] - с болью, но можно
- имеративные:
	- Gremlin
- фреймворки:
	- Pregel

##### Graph Databases vs CODASYL Network Model

###### Общий вопрос
На первый взгляд, сетевая модель CODASYL похожа на графовые базы данных. Являются ли графовые БД "вторым пришествием" CODASYL? **Нет** — есть важные различия.

###### Ключевые различия

| Аспект                   | CODASYL Network Model                                                             | Graph Databases                                                                               |
| ------------------------ | --------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| **Схема**                | Жёсткая схема определяла, какой тип записи может быть вложен в какой другой       | Нет ограничений — любая вершина может иметь рёбро к любой другой вершине                      |
| **Гибкость**             | Низкая — изменения схемы сложны                                                   | Высокая — легкая адаптация к изменяющимся требованиям                                         |
| **Доступ к данным**      | Единственный способ — пройти один из access paths                                 | Прямой доступ по уникальному ID или через индексы по значению                                 |
| **Упорядочивание**       | Дочерние записи — упорядоченное множество, БД поддерживает порядок                | Вершины и рёбра не упорядочены (сортировка только при запросе)                                |
| **Вставка данных**       | Приложения должны заботиться о позициях новых записей в множествах                | Нет необходимости заботиться о порядке при вставке                                            |
| **Языки запросов**       | Все запросы императивные, сложные в написании, легко ломались при изменении схемы | Поддержка как императивного кода, так и высокоуровневых декларативных языков (Cypher, SPARQL) |
| **Сложность разработки** | Высокая — сложные запросы, хрупкость к изменениям                                 | Низкая — декларативные запросы, устойчивость к изменениям                                     |

---
[[30 - Learning/10 - Foundation/30 - DDIA/0. PDFs of the book/DDIA M Klepman (after ipad)_250910_214423.pdf#page=61&selection=0,0,0,22|DDIA M Klepman (after ipad)_250910_214423, page 49 - Graph-like Models]]